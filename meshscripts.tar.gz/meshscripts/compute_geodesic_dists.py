import networkx as nx
import trimesh

def create_graph(v, f, usegeodesic = True):
    import trimesh
    import networkx as nx

    mesh = trimesh.Trimesh(v, f, process=False)

    # edges without duplication
    edges = mesh.edges_unique

    # the actual length of each unique edge
    if usegeodesic:
        length = mesh.edges_unique_length
    else:
        length = np.ones(len(edges))
    # create the graph with edge attributes for length
    graph = nx.Graph()
    for edge, L in zip(edges, length):
        graph.add_edge(*edge, length=L)

    return graph

def mesh_shortest_path(graph, start=0, end=3000):
    import networkx as nx

    # run the shortest path query using length for edge weight
    path = nx.shortest_path(graph,
                            source=start,
                            target=end,
                            weight='length')

    return path

def visu_path(v, f, path, start, end):
    import trimesh

    mesh = trimesh.Trimesh(v, f, process=False)
    # VISUALIZE RESULT
    # make the sphere transparent-ish
    mesh.visual.face_colors = [100, 100, 100, 100]
    # Path3D with the path between the points
    path_visual = trimesh.load_path(mesh.vertices[path])
    # visualizable two points
    points_visual = trimesh.points.PointCloud(mesh.vertices[[start, end]])

    # create a scene with the mesh, path, and points
    scene = trimesh.Scene([
        points_visual,
        path_visual,
        mesh])

    scene.show(smooth=False)

def parallel_mesh_shortest_path(graph, i, j):
    path = mesh_shortest_path(graph, i, j)
    return (i,j,len(path)-1)


# how to compute shortest paths for mesh
MODEL_FOLDER = '/ps/project/common/expose_release/models/'
body_model = smplx.create(model_path=MODEL_FOLDER, gender='neutral', model_type='smplx')
body = body_model()
vertices = body.vertices[0]
graph = create_graph(vertices, body_model.faces)
shortest_path_length = dict(nx.all_pairs_dijkstra_path_length(graph, weight='length'))