"""
This script calculates the per part volumes of a SMPLX mesh .
"""

import argparse
import numpy as np
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))
sys.path.append('smplify-xmc-support')
import trimesh
import json
from body_segmentation import PartMeshCloser
from lib.utils.mesh_utils import get_submesh
from utils.constants import ESSENTIALS_DIR,SMPLX_VERT_SEG
from utils.meshscripts.smplx_constants import SMPLX_TPOSE_MESH, smplx_parts_yogi, smplx_boundaries_yogi, smplx_part_boundaries_yogi, missing_head_verts, smplx_gapfill_verts
import pickle as pkl


def combine_sub_parts():
    """ Combine smplx subparts to major parts"""

    # Load smpl vert segmentation json in smplx package
    with open(SMPLX_VERT_SEG, 'rb') as f:
        smplx_vert_seg = json.load(f)

    major_vert_seg = {}
    # combine all subpart vertices
    for part, subparts in smplx_parts_yogi.items():
        major_vert_seg[part] = []
        for subpart in subparts:
            major_vert_seg[part] += smplx_vert_seg[subpart]
            if part == 'head':
                major_vert_seg[part] += missing_head_verts
            # remove duplicates
            major_vert_seg[part] = list(set(major_vert_seg[part]))
    return major_vert_seg

def add_tuch_thighs_torso(major_vert_seg, smplx_mesh):
    # add thighs to major_vet_seg, by subtracting smplx shin+foot from touch leg
    right_tuch_thigh = os.path.join(ESSENTIALS_DIR, 'segments/smplx/smplx_segment_right_thigh.ply')
    right_tuch_thigh_mesh = trimesh.load(right_tuch_thigh, process=False)
    part_vert_id = [i for i, vc in enumerate(right_tuch_thigh_mesh.visual.vertex_colors) if
                    np.array_equal(vc, [255, 0, 0, 2])]  # remove vertices that are in smplx shin and foot
    part_vert_id = list(set(part_vert_id) - set(major_vert_seg['rightLowerLeg']))
    major_vert_seg['rightThigh'] = part_vert_id
    # add back goundary vertices
    for bound, bound_vid in smplx_part_boundaries_yogi['rightLowerLeg'].items():
        major_vert_seg['rightLowerLeg'] = major_vert_seg['rightLowerLeg'] + bound_vid

    left_tuch_thigh = os.path.join(ESSENTIALS_DIR, 'segments/smplx/smplx_segment_left_thigh.ply')
    left_tuch_thigh_mesh = trimesh.load(left_tuch_thigh, process=False)
    part_vert_id = [i for i, vc in enumerate(left_tuch_thigh_mesh.visual.vertex_colors) if
                    np.array_equal(vc, [255, 0, 0, 2])]
    # remove vertices that are in smplx shin and foot
    part_vert_id = list(set(part_vert_id) - set(major_vert_seg['leftLowerLeg']))
    major_vert_seg['leftThigh'] = part_vert_id
    # add back goundary vertices
    for bound, bound_vid in smplx_part_boundaries_yogi['leftLowerLeg'].items():
        major_vert_seg['leftLowerLeg'] = major_vert_seg['leftLowerLeg'] + bound_vid

    # add the torso to major part by subtracting all other vertex ids from smplx vertex ids
    torso_vert_id = list(range(len(smplx_mesh.vertices)))
    for part, part_vert_seg in major_vert_seg.items():
        torso_vert_id = list(set(torso_vert_id) - set(part_vert_seg))
    major_vert_seg['torso'] = torso_vert_id
    # Add boundary vertices again as removed due to subtraction
    for bound, bound_vid in smplx_part_boundaries_yogi['torso'].items():
        major_vert_seg['torso'] = major_vert_seg['torso'] + bound_vid
    major_vert_seg['torso'] = list(set(major_vert_seg['torso']))
    return major_vert_seg

def add_extra_gapfill_verts(major_vert_seg, smplx_mesh):
    # if you do not do this, some vertices on the boundaries are not added in any part
    # add the extra vertices to the major part
    for part, part_vert_seg in smplx_gapfill_verts.items():
        major_vert_seg[part] = major_vert_seg[part] + part_vert_seg
    return major_vert_seg


def visualize_parts(major_vert_seg, smplx_mesh, out_mesh_dir):
    # visualize the parts
    part_mesh_dir = os.path.join(out_mesh_dir, 'part_meshes_ply')
    os.makedirs(part_mesh_dir, exist_ok=True)
    part_vid_fid = {}
    for part, vert_id in major_vert_seg.items():
        # get face_id
        _, _, bool_faces, _ = get_submesh(smplx_mesh.vertices, smplx_mesh.faces, np.array(vert_id))
        face_ids = np.where(bool_faces)[0]
        part_vid_fid[part] = {'vert_id': vert_id, 'face_id': list(face_ids)}

        new_mesh = smplx_mesh.copy()
        new_mesh.visual.vertex_colors[vert_id] = [255, 0, 0, 255]
        new_mesh.export(os.path.join(part_mesh_dir, f'smplx_segment_{part}.ply'))

    with open(os.path.join(part_mesh_dir, 'smplx_part_vid_fid.pkl'), 'wb') as f:
        pkl.dump(part_vid_fid, f)

    ## save fid to part name mapping - needed for volume com
    fid_to_part = dict({k: [] for k in range(len(new_mesh.faces))})
    # create fid to part dictionary and save as pkl
    for part_label, part_vid_fid in part_vid_fid.items():
        for fid in part_vid_fid['face_id']:
            if part_label not in fid_to_part[fid]:
                fid_to_part[fid].append(part_label)
    # check if no multiple part names per face
    for fid, part_names in fid_to_part.items():
        if len(part_names) > 2:
            print('Warning: more than two part labels for face {}'.format(fid))
            import ipdb;
            ipdb.set_trace()
        if len(part_names) <= 2:
            fid_to_part[fid] = part_names[0]
    with open(os.path.join(part_mesh_dir, 'fid_to_part.pkl'), 'wb') as f:
        pkl.dump(fid_to_part, f)

    with open(os.path.join(part_mesh_dir, 'smplx_segments_bounds.pkl'), 'wb') as f:
        pkl.dump(smplx_part_boundaries_yogi, f)
    return part_mesh_dir


def visualize_boundaries(smplx_mesh, out_mesh_dir):
    # visualize the boundary vertices
    part_bound_dir = os.path.join(out_mesh_dir, 'part_bounds_ply')
    os.makedirs(part_bound_dir, exist_ok=True)
    bound_mesh = smplx_mesh.copy()
    for boundary, vert_id in smplx_boundaries_yogi.items():
        bound_mesh.visual.vertex_colors[:] = [0, 0, 0, 0]
        bound_mesh.visual.vertex_colors[vert_id] = [255, 255, 0, 2]
        bound_mesh.export(os.path.join(part_bound_dir, f'smplx_part_bounds_{boundary}.ply'))

def get_per_part_volume(smplx_mesh, segments_folder, out_mesh_dir):
    per_part_volume = {}
    total = 0

    part_dir = os.path.join(out_mesh_dir, 'only_part_ply')
    os.makedirs(part_dir, exist_ok=True)
    # calculate the volume of each part
    for part_name, part_bounds in smplx_part_boundaries_yogi.items():
        # close the part in the full smplx mesh
        segment_path = f'{segments_folder}/smplx_segment_{part_name}.ply'
        smplx_mesh_part_closed = PartMeshCloser(part_name, smplx_mesh, segments_folder)
        colored_mesh = trimesh.load(segment_path, process=False)
        part_vert_ids = np.where(np.array(colored_mesh.visual.vertex_colors[:, 0]) == 255)[0]
        extra_vert_ids = np.arange(len(smplx_mesh.vertices), len(smplx_mesh_part_closed.vertices))
        part_vert_ids = np.concatenate([part_vert_ids, extra_vert_ids], axis=0)
        part_verts_closed, part_faces_closed, _, _ = get_submesh(smplx_mesh_part_closed.vertices, smplx_mesh_part_closed.faces, part_vert_ids)
        part_mesh_closed = trimesh.Trimesh(part_verts_closed, part_faces_closed, process=False)
        # part_mesh_closed.fix_normals()
        assert part_mesh_closed.is_volume, 'part mesh is not a valid volume'
        part_mesh_closed.export(os.path.join(part_dir, f'{part_name}_closed.ply'))
        part_volume = part_mesh_closed.volume
        per_part_volume[part_name] = part_volume
        total += part_volume
        print(f'{part_name}: {part_volume * 1000:.2f}')
    print(f'total: {total * 1000:.2f}')
    # save as a json
    with open(os.path.join(out_mesh_dir, 'per_part_volume.json'), 'w') as f:
        json.dump(per_part_volume, f)

def main(out_mesh_dir):
    # load smplx mesh
    smplx_mesh = trimesh.load(SMPLX_TPOSE_MESH, process=False)

    major_vert_seg = combine_sub_parts()
    major_vert_seg = add_tuch_thighs_torso(major_vert_seg, smplx_mesh)
    major_vert_seg = add_extra_gapfill_verts(major_vert_seg, smplx_mesh)
    part_mesh_dir  = visualize_parts(major_vert_seg, smplx_mesh, out_mesh_dir)

    # visualize the boundaries
    os.makedirs(out_mesh_dir, exist_ok=True)
    visualize_boundaries(smplx_mesh, out_mesh_dir)

    # get_per_part_volume
    get_per_part_volume(smplx_mesh, part_mesh_dir, out_mesh_dir)

    # save major vert seg as json
    with open(os.path.join(out_mesh_dir, 'smplx_segments_vertex_ids.pkl'), 'w') as f:
        json.dump(major_vert_seg, f)



if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--out_mesh_dir', type=str, required=True, default='../../smplify-xmc-support/data/essentials/yogi_segments/smplx')
    args = parser.parse_args()
    main(args.out_mesh_dir)


